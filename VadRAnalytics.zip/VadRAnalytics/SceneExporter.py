import os, shutil
from shutil import copyfile
from PIL import Image

vadr_folder = "VadrSceneExport"
current_directory = os.getcwd()
vadr_folder_path = os.path.join(current_directory, vadr_folder)

class Material:

	def __init__(self, name, cwd, mat_index, mat_prefix, vadr_folder_path):
		self.name = name
		self.new_name = "{}{}".format(mat_prefix, str(mat_index))
		self.mat_index = mat_index
		self.mat_prefix = mat_prefix
		self.cwd = cwd
		self.param = {}
		self.files = {}
		self.vadr_folder_path = vadr_folder_path
		self.file_path = cwd
		if '/' in name:
			file_path_split = self.name.split('/')
			for i in range(0, len(file_path_split) -1):
				if file_path_split[i] != "":
					self.file_path = os.path.join(self.file_path, file_path_split[i])

	def __str__(self):
		return "{}\n\t{}\n\t{}\n\t{}".format(self.name, self.file_path, self.param, self.files)
	
	def handle_material(self):
		material_string = "newmtl {}\n".format(self.new_name)
		for param in self.param:
			material_string += "\t{} {}\n".format(param, self.param[param])
		file_index = 1
		for file in self.files:
			new_file_name = "{}{}.png".format(self.new_name, file_index)
			# copy file from original location to given directory
			read_path = os.path.join(self.file_path, self.files[file])
			write_path = os.path.join(self.vadr_folder_path, new_file_name)
			try:
				# copyfile(read_path, write_path)
				import_file = Image.open(read_path)
				import_file.save(write_path)
				saved_file_size = os.path.getsize(write_path)
				# loop until file size becomes less than 2 MB
				while (saved_file_size > 2 * 1024 * 1024):
					saved_image = Image.open(write_path)
					saved_image_dim = saved_image.size
					saved_image = saved_image.resize((saved_image_dim[0] // 2, saved_image_dim[1] // 2), Image.ANTIALIAS)
					saved_image.save(write_path, quality = 100)
					saved_file_size = os.path.getsize(write_path)
				material_string += "\t{} {}\n".format(file, new_file_name)
			except Exception as e:
				raise Exception(("Texture file: {} not found, Aborting.").format(read_path))
			file_index += 1
		return material_string


# get the mtl and obj file path
mtl_file_name = False
obj_file_name = False
for filename in os.listdir(current_directory):
	if filename.endswith(".mtl"):
		if not mtl_file_name:
			mtl_file_name = filename
		else:
			raise Exception("More than one mtl file")
	elif filename.endswith(".obj"):
		if not obj_file_name:
			obj_file_name = filename
		else:
			raise Exception("More than one obj file")
if not mtl_file_name or not obj_file_name:
	raise Exception("Either .mtl for .obj file not found")
else:	
	print("Mtl and obj files are", mtl_file_name, obj_file_name)

# now make a map of all the textures from the .mtl file
mtl_file = open(os.path.join(current_directory, mtl_file_name))
mtl_file_line_list = mtl_file.readlines()

obj_file = open(os.path.join(current_directory, obj_file_name))
obj_file_line_list = obj_file.readlines()

material_list = []
param_list = {
	"map_Kd": "map",
	"map_Ks": "map",
	"Kd": "value",
	"d": "value",
	"Tr": "value",
}
param_list_keys = [param for param in param_list]

cur_material = None
material_index = 0
for mtl_file_line in mtl_file_line_list:
	try:
		newmtl_index = mtl_file_line.index("newmtl")
		material_index += 1
		mtl_file_line = mtl_file_line[newmtl_index:]
		material_name = mtl_file_line[6:].strip()
		file_path = None
		if '/' in material_name:
			file_path = material_name
		if (cur_material):
			material_list.append(cur_material)
		cur_material = Material(material_name, current_directory, material_index, "vadr_material", vadr_folder_path)
	except Exception as e:
		mtl_file_line = mtl_file_line.strip()
		for param in param_list_keys:
			if mtl_file_line.startswith(param):
				if param_list[param] == "map":
					map_file = mtl_file_line[len(param):].strip()
					cur_material.files[param] = map_file
				elif param_list[param] == "value":
					param_value = mtl_file_line[len(param):].strip()
					cur_material.param[param] = param_value
				break

if cur_material:
	material_list.append(cur_material)

# create a directory for vadr files
if os.path.isdir(vadr_folder_path):
	print("Directory exists: cleaning")
	shutil.rmtree(vadr_folder_path)
os.mkdir(vadr_folder_path)

# now create mtl and obj files 
mtl_file_string = ""
for material in material_list:
	mtl_file_string += material.handle_material()
with open(os.path.join(vadr_folder_path, mtl_file_name), "w") as mtl_file:
	mtl_file.write(mtl_file_string)
	mtl_file.close()

# replace material names in obj file
for i in range(0, len(obj_file_line_list)):
	obj_file_line = obj_file_line_list[i]
	try:
		material_index = obj_file_line.index('usemtl')
		material_name = obj_file_line[material_index + 7:].strip()
		for material in material_list:
			if material.name == material_name:
				obj_file_line_list[i] = obj_file_line[: material_index + 6] + " " + material.new_name
				break
	except Exception as e:
		continue
new_obj_string = ""
for obj_file_line in obj_file_line_list:
	new_obj_string += obj_file_line
	if not new_obj_string.endswith("\n"):
		new_obj_string += "\n"
with open(os.path.join(vadr_folder_path, obj_file_name), "w") as obj_file:
	obj_file.write(new_obj_string)
	obj_file.close()

print("Export done. Upload the images in your applicaiton scene.")
