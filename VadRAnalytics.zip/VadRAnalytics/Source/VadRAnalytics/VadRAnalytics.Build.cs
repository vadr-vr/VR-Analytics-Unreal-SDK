// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

namespace UnrealBuildTool.Rules
{
	public class VadRAnalytics : ModuleRules
	{
		public VadRAnalytics(TargetInfo Target)
		{
			PublicIncludePaths.AddRange(
				new string[] {
					// ... add public include paths required here ...
					"VadRAnalytics/Public"
				}
				);

			PrivateIncludePaths.AddRange(
				new string[] {
					"VadRAnalytics/Private"
					// ... add other private include paths required here ...
				}
				);

			PublicDependencyModuleNames.AddRange(
				new string[]
				{
					"Core",
					"Engine",
					"CoreUObject",
					"InputCore",
					"HTTP",
					"Json",
                    "JsonUtilities",
                    //"UnrealEd"
					// ... add other public dependencies that you statically link with here ...
				}
				);

			PublicIncludePathModuleNames.AddRange(
                new string[] {
                    "Core",
                    "Engine",
					"HTTP"
					// ... add public include paths required here ...
				}
				);

			PrivateDependencyModuleNames.AddRange(
				new string[]
				{
					// ... add private dependencies that you statically link with here ...
				}
				);

			DynamicallyLoadedModuleNames.AddRange(
				new string[]
				{
					// ... add any modules that your module loads dynamically here ...
				}
				);
            if (UEBuildConfiguration.bBuildEditor)//we only want this to be included for editor builds but not packaged builds
            {
                PublicDependencyModuleNames.AddRange(
                    new string[] {
                    "UnrealEd",
                    "Slate",
                    "SlateCore",
                    "EditorStyle"
                    }
                );
            }
        }
	}
}