// Fill out your copyright notice in the Description page of Project Settings.

#include "VadRAnalytics.h"
#include "GameFramework/Actor.h"
#include "Private/Utils/FileWriteWorker.h"
#include "Private/Utils/PostDataWorker.h"
#include "Private/Utils/utils.h"
#if WITH_EDITOR
#include "UnrealEd.h"
#endif

#define LOCTEXT_NAMESPACE "ExportLevel"

using namespace vadranalytics;

VadRAnalytics::VadRAnalytics()
{
	this->RegisterSessionToken();
	this->session.SetOs(UGameplayStatics::GetPlatformName());
	// UE_LOG(VadRLog, Warning, TEXT("Session token after register: %s. Time: %d"), *session.GetSessionToken(), session.GetSessionStartTime());
}

// VadRAnalytics* VadRAnalytics::instance;


void VadRAnalytics::StartupModule()
{
	// This code will execute after your module is loaded into memory (but after global variables are initialized, of course.)
	VadRLog::Log("Log", "VadR Module has loaded");
}


void VadRAnalytics::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

void VadRAnalytics::Init(FString inAppId, FString inAppToken, FString inVersionNo, bool inTestMode)
{
	this->appId = inAppId;
	this->appToken = inAppToken;
	this->versionNo = inVersionNo;
	FString tempToken = FPlatformMisc::GetDeviceId();
	this->appDeviceToken = tempToken;
	this->deviceToken = tempToken;
	this->session.SetTestMode(inTestMode);
	VadRLog::Log("Log", "AppId: "+this->appId+" AppToken: "+this->appToken+" Version: "+this->versionNo+" Device: "+this->appDeviceToken);
}

void VadRAnalytics::StartScene(FString inSceneId, float time)
{
	if(inSceneId.Len() > 0)
	{
		//Set Scene Id of the data script. Get StartTime of the level here. Probably from calling a function
		// VadRAnalytics* self = VadRAnalytics::GetInstance();
		this->event_mutex.Lock();
			this->sceneId = inSceneId;
			this->sceneToken = utils::GetToken();
			this->sceneStartTime = time;
			this->sceneStartUnixTime = utils::GetUnixTime();
			VadRLog::Log("Log", "Scene Start Time: " + utils::ToString(this->sceneStartTime));
		this->event_mutex.Unlock();
	}
}

void VadRAnalytics::RegisterEvent(FString eventName, FVector position, float time)
{
	//Get the time of the event since level start
	EventClass tempEvent(eventName, position, time - this->sceneStartTime);
	//VadRAnalytics* self = VadRAnalytics::GetInstance();
	this->RegisterEventHelper(tempEvent);
}

void VadRAnalytics::RegisterEvent(FString eventName, FVector position, TMap<FString, float> info, float time)
{
	//Get the time of the event since level start
	EventClass tempEvent(eventName, position, info, time - this->sceneStartTime);
	//VadRAnalytics* self = VadRAnalytics::GetInstance();
	this->RegisterEventHelper(tempEvent);
}

void VadRAnalytics::RegisterEvent(FString eventName, FVector position, TMap<FString, FString> filter, float time)
{
	//Get the time of the event since level start
	EventClass tempEvent(eventName, position, filter, time - this->sceneStartTime);
	//VadRAnalytics* self = VadRAnalytics::GetInstance();
	this->RegisterEventHelper(tempEvent);
}

void VadRAnalytics::RegisterEvent(FString eventName, FVector position, TMap<FString, float> info, TMap<FString, FString> filter, float time)
{
	//Get the time of the event since level start
	EventClass tempEvent(eventName, position, info, filter, time - this->sceneStartTime);
	//VadRAnalytics* self = VadRAnalytics::GetInstance();
	this->RegisterEventHelper(tempEvent);
}

void VadRAnalytics::RegisterEventHelper(EventClass singleEvent)
{
	//Get proper scene here
	this->event_mutex.Lock();
		SceneClass tempScene("sceneName", this->sceneId, this->sceneToken, this->sceneStartUnixTime);
	//try {
		SceneClass* scene = session.AddScene(tempScene);
		scene->AddEventToScene(singleEvent);
	/*}
	catch (std::exception& e) {
		// UE_LOG(VadRLog, Warning, "Exception in registering event %s", e.what());
	}*/
	this->event_mutex.Unlock();
	
}

FString VadRAnalytics::StartEvent(FString eventName) {
	StartEndEvents* tempEvent = new StartEndEvents(eventName);
	FString tempToken = utils::GetToken();
	startEndEvents.Add(tempToken, tempEvent);
	return tempToken;
}

FString VadRAnalytics::StartEvent(FString eventName, TMap<FString, FString> filters) {
	StartEndEvents* tempEvent = new StartEndEvents(eventName, filters);
	FString tempToken = utils::GetToken();
	startEndEvents.Add(tempToken, tempEvent);
	return tempToken;
}

FString VadRAnalytics::StartEvent(FString eventName, TMap<FString, float> info) {
	StartEndEvents* tempEvent = new StartEndEvents(eventName, info);
	FString tempToken = utils::GetToken();
	startEndEvents.Add(tempToken, tempEvent);
	return tempToken;
}

FString VadRAnalytics::StartEvent(FString eventName, TMap<FString, float> info, TMap<FString, FString> filters) {
	StartEndEvents* tempEvent = new StartEndEvents(eventName, info, filters);
	FString tempToken = utils::GetToken();
	startEndEvents.Add(tempToken, tempEvent);
	return tempToken;
}

void VadRAnalytics::EndEvent(FString eventId, FVector pos, float gameTime) {
	for (auto& Elem: startEndEvents) {
		if (Elem.Key == eventId) {
			(Elem.Value)->RegisterEnd(pos, gameTime);
			startEndEvents.Remove(eventId);
		}
	}
}

void VadRAnalytics::WriteToFile() 
{
	//VadRAnalytics* self = VadRAnalytics::GetInstance();
	this->event_mutex.Lock();
	SessionData tempSession;
	//try {
		tempSession = this->session;
		this->session = SessionData();
		this->session.SetSessionToken(tempSession.GetSessionToken());
		this->session.SetOs(tempSession.GetOs());
		this->session.SetDevice(tempSession.GetDevice());
		this->session.SetLocation(tempSession.GetLocation());
		this->session.SetConnection(tempSession.GetConnection());
		this->session.SetLanguage(tempSession.GetLanguage());
		this->session.SetSessionStartTime(tempSession.GetSessionStartTime());
	/*}
	catch (std::exception& e) {

	}*/
	this->event_mutex.Unlock();

	FString request = "{";
	request += tempSession.ConvertToString() + "}\n";
	this->file_mutex.Lock();
	//try {
		FString filePath = FPaths::GamePersistentDownloadDir() + "/" + this->ANALYTICS_FILE;
		FFileHelper::SaveStringToFile(request, *filePath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), FILEWRITE_Append);
		// UE_LOG(VadRLog, Warning, TEXT("File Path: %s"), *filePath);
	/*}
	catch (std::exception& e) {

	}*/
	this->file_mutex.Unlock();	
}

void VadRAnalytics::PersistData() 
{
	FileWriteWorker* fileWriterThread = new FileWriteWorker();
}

void VadRAnalytics::RegisterSessionToken()
{
	int64 currentTime = utils::GetUnixTime()/1000;
	// UE_LOG(VadRLog, Log, TEXT("Current Time is %d "), currentTime);
	FString fileData = "";
	FString filePath = FPaths::GamePersistentDownloadDir() + "/" + this->TOKEN_FILE;
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

	if (PlatformFile.FileExists(*filePath)) {
		FFileHelper::LoadFileToString(fileData, *filePath);
		TArray<FString> lines;
		int32 lineCount = fileData.ParseIntoArray(lines, TEXT("\n"), true);
		if (lineCount == 2)
		{
			FString tempToken = lines[0];
			double tempTime = FCString::Atod(*lines[1]);
			if (currentTime - tempTime < 600) { //Ten Minutes
				this->session.SetSessionToken(tempToken);
				this->session.SetSessionStartTime(tempTime);
				return;
			}
		}
	}
	FString new_token = utils::GetToken();
	this->session.SetSessionToken(new_token);
	this->session.SetSessionStartTime(currentTime);
	FFileHelper::SaveStringToFile(new_token + "\n" + utils::ToString(currentTime), *filePath);
	return;
}

FString VadRAnalytics::ReadFromFile()
{
	FString request = "";
	FString FileData = "";
	////VadRAnalytics* self = VadRAnalytics::GetInstance();
	FString filePath = FPaths::GamePersistentDownloadDir() + "/" + this->ANALYTICS_FILE;
	FString fileBackupPath = FPaths::GamePersistentDownloadDir() +"/" + this->ANALYTICS_FILE_BACK;
	this->file_mutex.Lock();

	//try {
		IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
		if (PlatformFile.FileExists(*filePath))
		{
			FFileHelper::LoadFileToString(FileData, *filePath);
		}
	/*}
	catch (std::exception& e) {

	}*/
	this->file_mutex.Unlock();
	// UE_LOG(VadRLog, Log, TEXT("File String: \n %s"), *FileData);
	TArray<FString> lines;
	int32 lineCount = FileData.ParseIntoArray(lines, TEXT("\n"), true);
	for (auto& line : lines) 
	{
		// UE_LOG(VadRLog, Log, TEXT("File Line: \n %s"), *line);
		FFileHelper::SaveStringToFile(line + ",", *fileBackupPath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), FILEWRITE_Append);
	}
	FPlatformFileManager::Get().GetPlatformFile().DeleteFile(*filePath);
	FString FileBackupData = "";
	FFileHelper::LoadFileToString(FileBackupData, *fileBackupPath);
	// UE_LOG(VadRLog, Log, TEXT("Request Line: \n %s"), *FileBackupData);
	return FileBackupData;
}

void VadRAnalytics::PostToServer()
{
	//VadRAnalytics* self = VadRAnalytics::GetInstance();
	if(this->appId.Len() == 0 || this->appToken.Len() == 0 || this->versionNo.Len() == 0){
		VadRLog::Log("Error", "App Id or App Token or Version not provided.");
		return;
	}
	TSharedRef<IHttpRequest> HttpRequest = FHttpModule::Get().CreateRequest();
	FHttpModule::Get().SetHttpTimeout((float)(this->timeout + 5));
	HttpRequest->SetVerb("POST");
	HttpRequest->SetHeader("Content-Type", "application/json");
	HttpRequest->SetURL(*FString::Printf(TEXT("%s"), *this->ANALYTICS_URL));
	FString request = "{\"AppId\":" + this->appId + ",";
	if (this->deviceToken.Len() > 0)
	{
		request += "\"DeviceToken\":\"" + this->deviceToken + "\",";
	}
	if (this->appDeviceToken.Len() > 0)
	{
		request += "\"AppDeviceToken\":\"" + this->appDeviceToken + "\",";
	}
	request += "\"Version\":\"" + this->versionNo + "\"," + "\"AppToken\":\"" + this->appToken + "\", \"Sessions\":[";
	request += this->ReadFromFile();
	if (request[request.Len() - 1] == ',')
	{
		request = request.Mid(0, request.Len() - 1);
	}
	request += "]}";
	// UE_LOG(VadRLog, Warning, TEXT("Request for Post is: %s"), *request);
	HttpRequest->SetContentAsString(request);
	HttpRequest->OnProcessRequestComplete().BindRaw(this, &VadRAnalytics::PostRequestComplete);
	HttpRequest->ProcessRequest();
}

void VadRAnalytics::SendData()
{
	PostDataWorker* postDataThread = new PostDataWorker();
}



void VadRAnalytics::PostRequestComplete(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	////VadRAnalytics* self = VadRAnalytics::GetInstance();
	if (!Response.IsValid()) 
	{
		VadRLog::Log("Warning", "Timeout Error in posting the data.");
	}
	else if (bWasSuccessful)
	{
		FString fileBackupPath = FPaths::GamePersistentDownloadDir() + "/" + this->ANALYTICS_FILE_BACK;
		FPlatformFileManager::Get().GetPlatformFile().DeleteFile(*fileBackupPath);
		VadRLog::Log("Log", "Data posted successfully.");
	}
	else
	{
		TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
		TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(Response->GetContentAsString());
		FJsonSerializer::Deserialize(JsonReader, JsonObject);
		if (JsonObject->HasField("delete")) {
			bool isDelete = JsonObject->GetBoolField("delete");
			// UE_LOG(VadRLog, Warning, TEXT("Delete Flag, %d") , isDelete);
			if (isDelete)
			{
				FString fileBackupPath = FPaths::GamePersistentDownloadDir() + "/" + this->ANALYTICS_FILE_BACK;
				FPlatformFileManager::Get().GetPlatformFile().DeleteFile(*fileBackupPath);
			}
		}
		// Handle error here
	}
}

void VadRAnalytics::ExportLevel(AActor* actor) {
	#if WITH_EDITOR
		UWorld* World = actor->GetWorld();
		GUnrealEd->PlayWorld->bDebugPauseExecution = true;
		int32 YesNoCancelReply = FMessageDialog::Open(EAppMsgType::YesNoCancel, NSLOCTEXT("UnrealEd", "Prompt_OBJExportWithBMP", "Export Selected Only? Yes - Selected Only, No- Export All."));
		
		switch (YesNoCancelReply)
		{
		case EAppReturnType::Yes:
			//exportSelected = true;
			setUpNotification(World, true);
			break;

		case EAppReturnType::No:
			//exportSelected = true;
			exportScene(World, false);

		case EAppReturnType::Cancel:
			GUnrealEd->PlayWorld->bDebugPauseExecution = false;
			return;
		}
		/*NotificationItem->ExpireAndFadeout();*/

	#endif
}

void VadRAnalytics::setUpNotification(UWorld* World, bool exportSelected) {
#if WITH_EDITOR
	const FText ExportButtonText = LOCTEXT("ExportButton_Text", "Export Scene");
	const FText ExportButtonTT = LOCTEXT("ExportButton_TTText", "Export Scene after selecting the objects.");
	FNotificationInfo Info(FText::FromString("Objects Selected?"));
	Info.FadeInDuration = 0.1f;
	Info.Image = FEditorStyle::GetDefaultBrush();
	Info.FadeOutDuration = 0.5f;
	Info.ExpireDuration = 1.5f;
	Info.bUseThrobber = true;
	Info.bUseSuccessFailIcons = false;
	Info.bUseLargeFont = true;
	Info.bFireAndForget = false;
	Info.bAllowThrottleWhenFrameRateIsLow = false;
	Info.ButtonDetails.Add(FNotificationButtonInfo(ExportButtonText, ExportButtonTT,
		FSimpleDelegate::CreateRaw(this, &VadRAnalytics::exportScene, World, exportSelected),
		SNotificationItem::CS_Success));
	NotificationScene = FSlateNotificationManager::Get().AddNotification(Info);
	NotificationScene->SetCompletionState(SNotificationItem::CS_Success);
#endif
}


void VadRAnalytics::exportScene(UWorld* World, bool exportSelected) {
#if WITH_EDITOR
	if (NotificationScene.IsValid()) {
		NotificationScene->ExpireAndFadeout();
		NotificationScene.Reset();
	}
	if (World != NULL) {
		FNotificationInfo Info(FText::FromString("Exporting Level"));
		Info.Image = FEditorStyle::GetDefaultBrush();
		Info.FadeInDuration = 0.1f;
		Info.FadeOutDuration = 0.5f;
		Info.ExpireDuration = 1.5f;
		Info.bUseThrobber = true;
		Info.bUseSuccessFailIcons = false;
		Info.bUseLargeFont = true;
		Info.bFireAndForget = false;
		Info.bAllowThrottleWhenFrameRateIsLow = false;
		auto NotificationItem = FSlateNotificationManager::Get().AddNotification(Info);
		NotificationItem->SetCompletionState(SNotificationItem::CS_Success);
		FString path = FPaths::GameContentDir();
		FString level_name =  World->GetMapName();
		FString directory = "VadrLevelExport_"+ level_name;
		if (FPaths::DirectoryExists(*(path + directory))) {
			FPlatformFileManager::Get().GetPlatformFile().DeleteDirectory(*(path + directory));
		}
		FString ExportFilename = path + directory + "/" + directory + ".obj";
		GEditor->ExportMap(World, *ExportFilename, exportSelected);
		NotificationItem->ExpireAndFadeout();
	}
	else {
		VadRLog::Log("Warning", "The World is NULL. Cannot Export Scene");
	}
	GUnrealEd->PlayWorld->bDebugPauseExecution = false;
#endif
}

VadRAnalytics::~VadRAnalytics()
{
	this->WriteToFile();
	for (auto& eve : this->startEndEvents) {
		delete eve.Value;
	}
}

IMPLEMENT_MODULE(VadRAnalytics, VadRAnalytics)