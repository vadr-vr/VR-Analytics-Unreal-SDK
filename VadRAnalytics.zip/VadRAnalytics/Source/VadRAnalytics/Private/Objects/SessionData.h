// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "Private/VadRAnalyticsPCH.h"
#include "Private/Objects/SceneClass.h"
#include "Private/Utils/utils.h"
/**
 * 
 */
namespace vadranalytics{
	class SessionData
	{
	private:
		FString sessionToken;
		FString os;
		FString device;
		FString location;
		FString connection;
		FString language;
		int64 sessionStartTime;
		TArray<SceneClass> scenes;
		bool testMode;
	public:
		SessionData();
		FString GetSessionToken();
		FString GetOs();
		FString GetDevice();
		FString GetLocation();
		FString GetConnection();
		FString GetLanguage();
		bool GetTestMode();
		int64 GetSessionStartTime();
		TArray<SceneClass> GetScenes();

		void SetSessionToken(FString inSessionToken);
		void SetOs(FString inOs);
		void SetDevice(FString inDevice);
		void SetLocation(FString inLocation);
		void SetConnection(FString inConnection);
		void SetLanguage(FString inLanguage);
		void SetSessionStartTime(int64 inSessionStartTime);
		void SetTestMode(bool inTestMode);
		FString ConvertToString();
		SceneClass * AddScene(SceneClass tempScene);
		~SessionData();
	}; 
}