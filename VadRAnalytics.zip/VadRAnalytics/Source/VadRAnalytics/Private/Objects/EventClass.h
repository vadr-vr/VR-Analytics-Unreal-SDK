// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "VadRAnalyticsPCH.h"
#include "Private/Utils/VadRLog.h"
/**
 *
 */
namespace vadranalytics{
	class EventClass
	{
	private:
		FVector position;
		FString eventName;
		float gameTime;
		double eventTime;
		TMap<FString, float> info;
		TMap<FString, FString> filters;
		FString RemoveSpecialCharacters(FString name);
		TMap<FString, float> CheckKeys(TMap<FString, float> dict);
	public:
		EventClass();
		EventClass(FString name, FVector position, float gameTime);
		EventClass(FString name, FVector position, TMap<FString, float> info, float gameTime);
		EventClass(FString name, FVector position, TMap<FString, FString> filters, float gameTime);
		EventClass(FString name, FVector position, TMap<FString, float> info, TMap<FString, FString> filters, float gameTime);
		FVector GetPosition();
		FString GetEventName();
		float GetGameTime();
		double GetEventTime();
		TMap<FString, float>  GetInfo();
		TMap<FString, FString> GetFilters();
		~EventClass();
	};
}