// Fill out your copyright notice in the Description page of Project Settings.
#include "VadRAnalytics.h"
#include "SceneClass.h"

using namespace vadranalytics;

SceneClass::SceneClass(FString inSceneName, FString inSceneId, FString inSceneToken, double inSceneStartTime)
{
	this->sceneName = inSceneName;
	this->sceneId = inSceneId;
	this->sceneToken = inSceneToken;
	this->sceneStartTime = inSceneStartTime;
}

void SceneClass::AddEventToScene(EventClass tempEvent)
{
	if (this->ValidateEvent(tempEvent)) {
		this->events.Add(tempEvent);
	}
}
bool SceneClass::ValidateEvent(EventClass tempEvent)
{
	bool flag = true;
	if (tempEvent.GetEventName().Len() <= 0 || tempEvent.GetEventName().Len() > 20) {
		if (tempEvent.GetEventName().Len() > 20) {
			VadRLog::Log("Warning", 
				"Event Name cannot be more than 20 characters. Event Name: " + tempEvent.GetEventName());
		}
		flag = false;
	}
	for (auto& Elem : tempEvent.GetInfo()) {
		if (Elem.Key.Len() <= 0) {
			flag = false;
		}
		else if (Elem.Key.Len() > 20) {
			VadRLog::Log("Warning",
				"Info Key cannot be more than 20 characters. Info Key: " + Elem.Key);
			flag = false;
		}
	}
	for (auto& Elem : tempEvent.GetFilters()) {
		if (Elem.Key.Len() <= 0 || Elem.Key.Len() <= 0) {
			flag = false;
		}
		if (Elem.Key.Len() > 20) {
			VadRLog::Log("Warning",
				"Filter Key cannot be more than 20 characters. Filter Key: " + Elem.Key);
			flag = false;
		}
		if (Elem.Value.Len() > 30) {
			VadRLog::Log("Warning",
				"Filter Value cannot be more than 30 characters. Filter Value: " + Elem.Value);
			flag = false;
		}
	}

	return flag;
}

FString SceneClass::GetSceneName()
{
	return this->sceneName;
}
FString SceneClass::GetSceneId() 
{
	return this->sceneId;
}
FString SceneClass::GetSceneToken()
{
	return this->sceneToken;
}
double SceneClass::GetSceneStartTime()
{
	return this->sceneStartTime;
}
TArray<EventClass> SceneClass::GetEvents()
{
	//There should be some way to aquire a lock here
	return this->events;
}
SceneClass::~SceneClass()
{
}
