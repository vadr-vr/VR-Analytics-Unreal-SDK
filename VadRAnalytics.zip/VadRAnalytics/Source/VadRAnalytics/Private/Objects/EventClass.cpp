// Fill out your copyright notice in the Description page of Project Settings.
#include "VadRAnalytics.h"
#include "EventClass.h"
#include "Private/Utils/utils.h"


using namespace vadranalytics;

EventClass::EventClass()
{
	this->eventName = "";
	this->gameTime = -1.0f;
	this->eventTime = utils::GetUnixTime();
}

EventClass::EventClass(FString inName, FVector inPosition, float inGameTime)
{
	this->eventName = RemoveSpecialCharacters(inName);
	this->position = inPosition;
	this->gameTime = inGameTime;
	this->eventTime = utils::GetUnixTime();
}

EventClass::EventClass(FString inName, FVector inPosition, TMap<FString, float> inInfo, float inGameTime)
{
	this->eventName = RemoveSpecialCharacters(inName);
	this->position = inPosition;
	this->gameTime = inGameTime;
	this->info = CheckKeys(inInfo);
	this->eventTime = utils::GetUnixTime();
}
EventClass::EventClass(FString inName, FVector inPosition, TMap<FString, FString> inFilters, float inGameTime)
{
	this->eventName = RemoveSpecialCharacters(inName);
	this->position = inPosition;
	this->gameTime = inGameTime;
	this->filters = inFilters;
	this->eventTime = utils::GetUnixTime();
}
EventClass::EventClass(FString inName, FVector inPosition, TMap<FString, float> inInfo, TMap<FString, FString> inFilters, float inGameTime)
{
	this->eventName = RemoveSpecialCharacters(inName);
	this->position = inPosition;
	this->gameTime = inGameTime;
	this->info = CheckKeys(inInfo);
	this->filters = inFilters;
	this->eventTime = utils::GetUnixTime();
}

//int64 EventClass::GetCurrentUnixtime()
//{
//
//}

FVector EventClass::GetPosition()
{
	return position;
}
FString EventClass::GetEventName() 
{
	return eventName;
}
float EventClass::GetGameTime() 
{
	return gameTime;
}
double EventClass::GetEventTime()
{
	return eventTime;
}
TMap<FString, float> EventClass::GetInfo()
{
	return info;
}
TMap<FString, FString> EventClass::GetFilters() 
{
	return filters;
}



FString EventClass::RemoveSpecialCharacters(FString name)
{
	if (name.Contains("!") || name.Contains("@") || name.Contains("#")
		|| name.Contains("$") || name.Contains("%") || name.Contains("^")
		|| name.Contains("&") || name.Contains("*") || name.Contains("(") || name.Contains(")")
		|| name.Contains(" - "))
	{
		VadRLog::Log("Warning", "Name cannot contain special characters(!@#$%^&*()-). Name: "+name);
		 //UE_LOG(VadRLog, Warning, TEXT("Event Name cannot have special characters (!@#$%^&*()-)"));
		return "";
	}
	return name;
}

TMap<FString, float> EventClass::CheckKeys(TMap<FString, float> dict) 
{
	TMap<FString, float> temp;
	if (dict.Contains("Count")) 
	{
		VadRLog::Log("Warning", "Info cannot have a key Count");
		return temp;
	}
	return dict;
}

EventClass::~EventClass()
{
}