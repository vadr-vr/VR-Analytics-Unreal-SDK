// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "VadRAnalyticsPCH.h"
#include "Private/Objects/EventClass.h"
/**
 * 
 */
namespace vadranalytics{
	class SceneClass
	{
	private:
		FString sceneName;
		FString sceneId;
		FString sceneToken;
		double sceneStartTime;
		TArray<EventClass> events;
		bool ValidateEvent(EventClass tempEvent);
	public:
		SceneClass(FString inSceneName, FString inSceneId, FString inSceneToken, double inSceneStartTime);
		void AddEventToScene(EventClass tempEvent);
		FString GetSceneName();
		FString GetSceneId();
		FString GetSceneToken();
		double GetSceneStartTime();
		TArray<EventClass> GetEvents();
		~SceneClass();
	};
}