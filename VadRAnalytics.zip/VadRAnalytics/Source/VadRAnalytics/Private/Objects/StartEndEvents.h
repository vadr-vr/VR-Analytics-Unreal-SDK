// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "VadRAnalyticsPCH.h"
#include "Private/Objects/EventClass.h"

/**
*
*/
namespace vadranalytics {
	class StartEndEvents
	{
	private:
		FString eventName;
		double startTime;
		TMap<FString, float> info; 
		TMap<FString, FString> filters;
	public:
		StartEndEvents(FString inEventName, TMap<FString,FString> inFilters);
		StartEndEvents(FString inEventName);
		StartEndEvents(FString inEventName, TMap<FString, float> inInfo);
		StartEndEvents(FString inEventName, TMap<FString, float> inInfo, TMap<FString, FString> inFilters);
		void RegisterEnd(FVector pos, float gameTime);
		~StartEndEvents();
	};
}