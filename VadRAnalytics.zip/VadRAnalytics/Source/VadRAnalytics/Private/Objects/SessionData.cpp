// Fill out your copyright notice in the Description page of Project Settings.
#include "VadRAnalytics.h"
#include "SessionData.h"

using namespace vadranalytics;

SessionData::SessionData()
{
	this->os = "";
	this->device = "";
	this->location = "";
	this->language = "";
	this->connection = "";
	this->sessionToken = "";
}
//There should be locks
FString SessionData::GetSessionToken()
{
	return this->sessionToken;
}
FString SessionData::GetOs()
{
	return this->os;
}
FString SessionData::GetDevice()
{
	return this->device;
}
FString SessionData::GetLocation()
{
	return this->location;
}
FString SessionData::GetConnection()
{
	return this->connection;
}
FString SessionData::GetLanguage()
{
	return this->language;
}
int64 SessionData::GetSessionStartTime()
{
	return this->sessionStartTime;
}
bool SessionData::GetTestMode()
{
	return this->testMode;
}
TArray<SceneClass> SessionData::GetScenes()
{
	return this->scenes;
}

void SessionData::SetTestMode(bool inTestMode)
{
	this->testMode = inTestMode;
}

void SessionData::SetSessionToken(FString inSessionToken)
{
	this->sessionToken = inSessionToken;
}
void SessionData::SetOs(FString inOs)
{
	this->os = inOs;
}
void SessionData::SetDevice(FString inDevice)
{
	this->device = inDevice;
}
void SessionData::SetLocation(FString inLocation)
{
	this->location = inLocation;
}
void SessionData::SetConnection(FString inConnection)
{
	this->connection = inConnection;
}
void SessionData::SetLanguage(FString inLanguage)
{
	this->language = inLanguage;
}
void SessionData::SetSessionStartTime(int64 inSessionStartTime)
{
	this->sessionStartTime = inSessionStartTime;
}
SceneClass * SessionData::AddScene(SceneClass tempScene)
{
	bool flag = false;
	int total = this->scenes.Num();
	for(int i=0; i<total; i++)
	{
		SceneClass* singleScene = &(this->scenes[i]);
		if (singleScene->GetSceneToken() == tempScene.GetSceneToken() && singleScene->GetSceneId() == tempScene.GetSceneId())
		{
			// UE_LOG(VadRLog, Warning, TEXT("Scene found: %s, %s"), *tempScene.GetSceneToken(), *tempScene.GetSceneToken());
			flag = true;
			return singleScene;
		}
	}
	if (!flag) 
	{
		scenes.Add(tempScene);
		// UE_LOG(VadRLog, Warning, TEXT("Scene not found: %s, %s"), *tempScene.GetSceneToken(), *tempScene.GetSceneId());
	}
	return &(this->scenes[total]);
}

FString SessionData::ConvertToString()
{
	FString request = "";
	request += "\"Token\" : \"" + this->sessionToken + "\",";
	request += "\"Time\" : " + utils::ToString(this->sessionStartTime)+",";
	if (this->testMode) {
		request += "\"test\" : \"true\",";
	}
	else {
		request += "\"test\" : \"false\",";
	}
	request += "\"Extra\" : {";
	if(this->os.Len() > 0)
		request += "\"os\" : \"" + this->os + "\",";
	if (this->device.Len() > 0)
		request += "\"device\" : \"" + this->device + "\",";
	if (this->location.Len() > 0)
		request += "\"location\" : \"" + this->location + "\",";
	if (this->language.Len() > 0)
		request += "\"language\" : \"" + this->language + "\",";
	if (this->connection.Len() > 0)
		request += "\"connection\" : \"" + this->connection + "\",";
	if (request[request.Len() - 1] == ',')
	{
		request = request.Mid(0, request.Len() - 1);
	}
	request += "},";
	request += "\"Scenes\":[";
	for (auto& singleScene : this->scenes)
	{
		request += "{\"SceneId\": \"" + singleScene.GetSceneId() + "\",";
		request += "\"SceneName\": \"" + singleScene.GetSceneName() + "\",";
		request += "\"SceneToken\": \"" + singleScene.GetSceneToken() + "\",";
		request += "\"SceneTime\": " + utils::ToString(singleScene.GetSceneStartTime()) + ",";
		request += "\"Events\": {";
		FString eventName = "\"EventName\" : [";
		FString position = "\"Position\":[";
		FString gameTime = "\"GameTime\":[";
		FString extra = "\"Extra\":[";
		FString eventTime = "\"EventTime\":[";
		TArray<EventClass> events = singleScene.GetEvents();
		for (auto& singleEvent : events)
		{
			// UE_LOG(VadRLog, Warning, TEXT("New Scene, %s"), *singleEvent.GetEventName());
			eventName += "\"" + singleEvent.GetEventName() + "\",";
			FVector eventPosition = singleEvent.GetPosition();
			position += "\"" + utils::ToString(eventPosition.X) + ","
				+ utils::ToString(eventPosition.Z) + ","
				+ utils::ToString(eventPosition.Y)+ "\",";
			gameTime += utils::ToString(singleEvent.GetGameTime()) + ",";
			eventTime += utils::ToString(singleEvent.GetEventTime()) + ",";
			FString fk = "\"FK\":[";
			FString fv = "\"FV\":[";
			FString ik = "\"IK\":[";
			FString iv = "\"IV\":[";
			extra += "{";
			//Fill fk, fv, ik and iv
			for (auto& Elem : singleEvent.GetFilters())
			{
				fk += "\"" +Elem.Key+"\",";
				fv += "\"" + Elem.Value + "\",";
			}
			for (auto& Elem : singleEvent.GetInfo())
			{
				ik += "\"" + Elem.Key + "\",";
				iv += utils::ToString(Elem.Value) + ",";
			}
			if (fk[fk.Len() - 1] == ',')
			{
				fk = fk.Mid(0, fk.Len() - 1);
			}
			if (fv[fv.Len() - 1] == ',')
			{
				fv = fv.Mid(0, fv.Len() - 1);
			}
			if (ik[ik.Len() - 1] == ',')
			{
				ik = ik.Mid(0, ik.Len() - 1);
			}
			if (iv[iv.Len() - 1] == ',')
			{
				iv = iv.Mid(0, iv.Len() - 1);
			}
			fk += "],";
			fv += "],";
			ik += "],";
			iv += "],";
			FString temp = fk + fv + ik + iv;
			if (temp.Len() > 0 && temp[temp.Len() - 1] == ',')
			{
				temp = temp.Mid(0, temp.Len() - 1);
			}
			extra += temp + "},";
		}
		if (eventName[eventName.Len() - 1] == ',')
		{
			eventName = eventName.Mid(0, eventName.Len() - 1);
		}
		if (position[position.Len() - 1] == ',')
		{
			position = position.Mid(0, position.Len() - 1);
		}
		if (gameTime[gameTime.Len() - 1] == ',')
		{
			gameTime = gameTime.Mid(0, gameTime.Len() - 1);
		}
		if (eventTime[eventTime.Len() - 1] == ',')
		{
			eventTime = eventTime.Mid(0, eventTime.Len() - 1);
		}
		if (extra[extra.Len() - 1] == ',')
		{
			extra = extra.Mid(0, extra.Len() - 1);
		}
		eventName += "],";
		position += "],";
		gameTime += "],";
		eventTime += "],";
		extra += "]";
		request += eventName + position + gameTime + eventTime + extra;
		request += "}},";
	}
	if (request[request.Len() - 1] == ',')
	{
		request = request.Mid(0, request.Len() - 1);
	}
	request += "]";
	return request;
}



SessionData::~SessionData()
{
	
}
