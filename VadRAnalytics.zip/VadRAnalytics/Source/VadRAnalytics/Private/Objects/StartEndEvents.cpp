
#include "VadRAnalytics.h"
#include "StartEndEvents.h"

using namespace vadranalytics;

StartEndEvents::StartEndEvents(FString inEventName) {
	this->eventName = inEventName;
	this->startTime = utils::GetUnixTime();
}

StartEndEvents::StartEndEvents(FString inEventName, TMap<FString, float> inInfo) {
	this->eventName = inEventName;
	this->startTime = utils::GetUnixTime();
	this->info = inInfo;
}

StartEndEvents::StartEndEvents(FString inEventName, TMap<FString, FString> inFilters) {
	this->eventName = inEventName;
	this->startTime = utils::GetUnixTime();
	this->filters = inFilters;
}

StartEndEvents::StartEndEvents(FString inEventName, TMap<FString, float> inInfo, TMap<FString, FString> inFilters) {
	this->eventName = inEventName;
	this->startTime = utils::GetUnixTime();
	this->filters = inFilters;
	this->info = inInfo;
}

void StartEndEvents::RegisterEnd(FVector pos, float gameTime) {
	float eventTime = utils::GetUnixTime() - this->startTime;
	this->info.Add("Time", eventTime/1000);
	if (this->filters.Num() > 0) {
		IVadRAnalytics::Get().RegisterEvent(this->eventName, pos, this->info, this->filters, gameTime);
	}
	else {
		IVadRAnalytics::Get().RegisterEvent(this->eventName, pos, this->info, gameTime);
	}
}

StartEndEvents::~StartEndEvents() {
}