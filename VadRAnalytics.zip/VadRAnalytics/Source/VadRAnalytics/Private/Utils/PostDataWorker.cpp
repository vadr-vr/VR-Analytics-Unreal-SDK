// Fill out your copyright notice in the Description page of Project Settings.
#include "VadRAnalytics.h"
#include "IVadRAnalytics.h"
#include "PostDataWorker.h"
#include "Private/Utils/utils.h"

using namespace vadranalytics;

PostDataWorker::PostDataWorker()
{
	FString token = utils::GetToken();
	Thread = FRunnableThread::Create(this, *token, 0, TPri_BelowNormal);
}

bool PostDataWorker::Init()
{
	//Init the Data 
	return true;
}

uint32 PostDataWorker::Run()
{
	IVadRAnalytics::Get().PostToServer();
	return 0;
}

void PostDataWorker::EnsureCompletion()
{
	if (Thread)
	{
		Thread->WaitForCompletion();
	}
}

PostDataWorker::~PostDataWorker()
{
	if (Thread)
	{
		//Cleanup the worker thread
		delete Thread;
		Thread = nullptr;
	}
}
