// Fill out your copyright notice in the Description page of Project Settings.
#include "VadRAnalytics.h"
#include "IVadRAnalytics.h"
#include "Private/Utils/FileWriteWorker.h"
#include "Private/Utils/utils.h"

using namespace vadranalytics;

FileWriteWorker::FileWriteWorker()
{
	FString token = utils::GetToken();
	Thread = FRunnableThread::Create(this, *token, 0, TPri_BelowNormal);
}

bool FileWriteWorker::Init()
{
	//Init the Data 
	return true;
}

uint32 FileWriteWorker::Run()
{
	/*FString request = "{";
	request += this->vadrSession->ConvertToString() + "}\n";
	vadrAnalytics->file_mutex.Lock();
	FString filePath = FPaths::GamePersistentDownloadDir() + "/" + vadrAnalytics->ANALYTICS_FILE;
	FFileHelper::SaveStringToFile(request, *filePath, FFileHelper::EEncodingOptions::AutoDetect, &IFileManager::Get(), FILEWRITE_Append);
	// UE_LOG(VadRLog, Warning, TEXT("File Path: %s"), *filePath);
	vadrAnalytics->file_mutex.Unlock();
	return 0;*/
	IVadRAnalytics::Get().WriteToFile();
	return 0;
}


void FileWriteWorker::EnsureCompletion()
{
	if (Thread)
	{
		Thread->WaitForCompletion();
	}
}


FileWriteWorker::~FileWriteWorker()
{
	if (Thread)
	{
		//Cleanup the worker thread
		delete Thread;
		Thread = nullptr;
	}
}
