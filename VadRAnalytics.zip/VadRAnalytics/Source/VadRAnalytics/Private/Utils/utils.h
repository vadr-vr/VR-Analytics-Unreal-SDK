#pragma once
#include "Private/VadRAnalyticsPCH.h"
/**
 * 
 */
namespace vadranalytics{
	class utils
	{
	public:
		utils();
		static double GetUnixTime();
		static FString GetToken();
		static FString ToString(int64 num);
		static FString ToString(float num);
		static FString ToString(double num);
		~utils();
	};
}