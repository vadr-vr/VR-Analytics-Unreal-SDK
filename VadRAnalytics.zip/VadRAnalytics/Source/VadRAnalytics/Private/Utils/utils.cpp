// Fill out your copyright notice in the Description page of Project Settings.
#include "VadRAnalytics.h"
#include "utils.h"
#include "Private/Utils/VadRLog.h"

using namespace vadranalytics;

utils::utils()
{
}

double utils::GetUnixTime()
{
	FDateTime now = FDateTime::UtcNow();
	int64 time = now.ToUnixTimestamp();
	int32 milliseconds = now.GetMillisecond();
	double time_milliseconds = time * 1000 + milliseconds;
	return time_milliseconds;
}

FString utils::GetToken() 
{
	FGuid new_token = FGuid::NewGuid();
	// UE_LOG(VadRLog, Warning, TEXT("Token is: %s"), *new_token.ToString());
	return new_token.ToString();
}

FString utils::ToString(int64 num)
{
	FString result = FString::FromInt(num);
	return result;
}

FString utils::ToString(float num)
{
	FString result = FString::SanitizeFloat(num);
	return result;
}

FString utils::ToString(double num)
{
	FString result = FString::SanitizeFloat(num);
	return result;
}

utils::~utils()
{
}
