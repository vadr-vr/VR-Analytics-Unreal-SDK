// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "Private/VadRAnalyticsPCH.h"
 
/**
 * 
 */
namespace vadranalytics{
	class FileWriteWorker : public FRunnable
	{
	private:
		//Thread to run the worker FRunnable on
		FRunnableThread* Thread;

	public:
		FileWriteWorker();
		void EnsureCompletion();
		void Write();
		//FRunnable interface.
		virtual bool Init();
		virtual uint32 Run();
		//virtual void Stop();

		~FileWriteWorker();
	};
}