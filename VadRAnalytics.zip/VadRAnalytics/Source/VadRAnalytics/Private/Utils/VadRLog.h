// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "Private/VadRAnalyticsPCH.h"
/**
 * 
 */

 DECLARE_LOG_CATEGORY_EXTERN(VadRLogger, Log, All);

namespace vadranalytics{
	class VadRLog
	{
	public:
		VadRLog();
		~VadRLog();
		 static void Log(FString severity, FString message);
	};
}
