// Fill out your copyright notice in the Description page of Project Settings.

#include "VadRAnalytics.h"
#include "VadRLog.h"

DEFINE_LOG_CATEGORY(VadRLogger);

using namespace vadranalytics;

VadRLog::VadRLog()
{

}

 void VadRLog::Log(FString severity, FString message)
 {
 	if(severity == "Log"){
 		UE_LOG(VadRLogger, Log, TEXT("%s"), *message);
 	}
 	else if(severity == "Warning"){
 		UE_LOG(VadRLogger, Warning, TEXT("%s"), *message);
 	}
 	else if(severity == "Error"){
 		UE_LOG(VadRLogger, Error, TEXT("%s"), *message);
 	}

 }

VadRLog::~VadRLog()
{
}
