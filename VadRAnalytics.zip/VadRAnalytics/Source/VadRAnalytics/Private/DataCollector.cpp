// Fill out your copyright notice in the Description page of Project Settings.

#include "VadRAnalytics.h"
//#if WITH_EDITOR
//#include "UnrealEd.h"
//#endif
#include "DataCollector.h"
// Sets default values for this component's properties

DEFINE_LOG_CATEGORY(VadRDataLogger);

UDataCollector::UDataCollector()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;
	position = true;
	gaze = true;
	fps = true;
	hitRange = 500.0f;
	collectionInterval = 0.3f;
	trackObjectTime = 0.0f;
	writeTime = 0.0f;
	postTime = 0.0f;
	// ...
}


// Called when the game starts
void UDataCollector::BeginPlay()
{
	Super::BeginPlay();
	currentTime = 0.0f;
	frameCount = 0;
	fpsCount = 0.0f;
	trackObjectTime = UGameplayStatics::GetRealTimeSeconds(GetWorld());
	// ...
	init();
	IVadRAnalytics::Get().SendData();
}


// Called every frame
void UDataCollector::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	currentTime += DeltaTime;
	writeTime += DeltaTime;
	postTime += DeltaTime;
	frameCount++;
	if (currentTime > collectionInterval) {	
		fpsCount = frameCount / currentTime;
		frameCount = 0;
		currentTime -= collectionInterval;
		if (position) {
			CollectPositionData();
		}
		if (gaze || trackObjects.Num() > 0) {
			CollectGazeData();
		}
		if (fps) {
			CollectFpsData();
		}
	}

	if (writeTime > writeDataFrequency) {
		writeTime -= writeDataFrequency;
		IVadRAnalytics::Get().PersistData();
	}
	if (postTime > postDataFrequency) {
		UE_LOG(VadRDataLogger, Log, TEXT("Posting Analytics Data to Server"));
		postTime -= postDataFrequency;
		IVadRAnalytics::Get().SendData();
	}
}



void UDataCollector::init() {
	if(appId.Len() == 0 || appToken.Len() == 0 || version.Len() == 0){
		UE_LOG(VadRDataLogger, Error, TEXT("App Id or App Token or Version not provided."));
		return;
	}
	IVadRAnalytics::Get().Init(appId, appToken, version, testMode);

	if(sceneId.Len() == 0){
		// VadRLog::Log("Error", "Scene Id not provided.");
		UE_LOG(VadRDataLogger, Error, TEXT("Scene Id not provided."));
		return;
	}
	float time = UGameplayStatics::GetRealTimeSeconds(GetWorld());
	IVadRAnalytics::Get().StartScene(sceneId, time);
}

void UDataCollector::CollectPositionData() {
	FVector pos = GetComponentLocation();
	float time = UGameplayStatics::GetRealTimeSeconds(GetWorld());
	IVadRAnalytics::Get().RegisterEvent("vadrPosition", pos, time);
}

void UDataCollector::CollectGazeData() {
	FHitResult* hitResult = new FHitResult();
	FVector startTrace = GetComponentLocation();
	FVector forwardVector = GetForwardVector();
	FVector endTrace = (forwardVector * hitRange) + startTrace;
	FCollisionQueryParams* cqp = new FCollisionQueryParams();
	float time = UGameplayStatics::GetRealTimeSeconds(GetWorld());
	if (GetWorld()->LineTraceSingleByChannel(*hitResult, startTrace, endTrace, ECC_Visibility, *cqp)) {
		FVector pos = hitResult->Location;
		if (gaze) {
			IVadRAnalytics::Get().RegisterEvent("vadrGaze", pos, time);
		}
		AActor* hitActor = hitResult->GetActor();
		if (hitActor != NULL) {
			if (trackObjects.Num() > 0) {
				for (auto& Elem : trackObjects) {
					if (Elem.Value == hitActor) {
						TMap<FString, FString> trackObjectFilter;
						trackObjectFilter.Add("Object", Elem.Key); //Add Viewing range also here
						TMap<FString, float> trackObjectInfo;
						trackObjectInfo.Add("Time", time - trackObjectTime); // Get Time here
						FString range = checkRange(hitResult, Elem.Value, forwardVector);
						trackObjectFilter.Add("Viewing Range", range);

						IVadRAnalytics::Get().RegisterEvent("vadrTrackObjects", pos, trackObjectInfo, trackObjectFilter, time);
					}
				}
			}
		}
	}
	trackObjectTime = time;
}

void UDataCollector::CollectFpsData() {
	if (fpsCount > 0) {
		FVector pos = GetComponentLocation();
		TMap<FString, float> info;
		info.Add("Value", fpsCount);
		float time = UGameplayStatics::GetRealTimeSeconds(GetWorld());
		IVadRAnalytics::Get().RegisterEvent("vadrFPS", pos, info, time);
	}
}

FString UDataCollector::checkRange(FHitResult* hit, AActor* actor, FVector forward) {
	TArray<FVector> diagnols = getDiagnols(actor);
	int32 len = diagnols.Num();
	float projection = 0.0f;
	for (int32 i = 0; i < len; i++) {
		FVector cross = FVector::CrossProduct(diagnols[i], forward);
		if (cross.Size() > projection) {
			projection = cross.Size();
		}
	}
	if (projection > 0 && hit->Distance / projection < 5) {
		return "Close Range";
	}
	else if (projection > 0 && hit->Distance / projection < 20) {
		return "Normal Range";
	}
	if (projection > 0 && hit->Distance / projection < 40) {
		return "Far Range";
	}
	return "Other";
}

//void UDataCollector::ExportLevel(FString directory) {
////#if WITH_EDITOR
////	UWorld* World = GetWorld();
////	FString path = FPaths::GameContentDir();
////	FString ExportFilename = path + directory + "/" + directory + ".obj";
////	GEditor->ExportMap(World, *ExportFilename, false);
////#endif
//}

TArray<FVector> UDataCollector::getDiagnols(AActor* actor) {
	FVector Origin;
	FVector BoundsExtent;
	TArray<FVector> diagnols;
	actor->GetActorBounds(false, Origin, BoundsExtent);
	FVector diagnol1(-2*BoundsExtent.X, -2*BoundsExtent.Y, -2*BoundsExtent.Z);
	FVector diagnol2(-2 * BoundsExtent.X, -2 * BoundsExtent.Y, 2*BoundsExtent.Z);
	FVector diagnol3(-2 * BoundsExtent.X, 2 * BoundsExtent.Y, -2 * BoundsExtent.Z);
	FVector diagnol4(2 * BoundsExtent.X, -2 * BoundsExtent.Y, -2 * BoundsExtent.Z);
	diagnols.Add(diagnol1);
	diagnols.Add(diagnol2);
	diagnols.Add(diagnol3);
	diagnols.Add(diagnol4);
	return diagnols;
}