
#include "VadRAnalytics.h"
#include "IVadRAnalytics.h"
#include "VadRAnalyticsBlueprint.h"
#include "Private/Utils/VadRLog.h"
#include "DataCollector.h"

// 
//UVadRAnalyticsBlueprint::UVadRAnalyticsBlueprint(const class FPostConstructInitializeProperties& PCIP)
//	: Super(PCIP)
//{
// 
//}

void UVadRAnalyticsBlueprint::StartVadrScene(FString inSceneId, float time){
	IVadRAnalytics::Get().StartScene(inSceneId, time);
}


void UVadRAnalyticsBlueprint::RegisterEvent(FString eventName, FVector position, float time){
	IVadRAnalytics::Get().RegisterEvent(eventName, position, time);
}

void UVadRAnalyticsBlueprint::RegisterEventWithInfo(FString eventName, FVector position,const TArray<FDataInfo>& info, float time){
	TMap<FString, float> infoMap;
	int32 arrayLength = info.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && info[i].key == info[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Info should have unique keys. Key: " + info[i].key + " duplicated for event: " + eventName);
			return;
		}
		else {
			infoMap.Add(info[i].key, info[i].value);
		}
	}
	IVadRAnalytics::Get().RegisterEvent(eventName, position, infoMap, time);
}


void UVadRAnalyticsBlueprint::RegisterEventWithFilter(FString eventName, FVector position, const TArray<FDataFilter>& filter, float time){
	TMap<FString, FString> filterMap;
	int32 arrayLength = filter.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && filter[i].key == filter[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Filters should have unique keys. Key: " + filter[i].key + " duplicated for event: " + eventName);
			return;
		}
		else {
			filterMap.Add(filter[i].key, filter[i].value);
		}
	}
	IVadRAnalytics::Get().RegisterEvent(eventName, position, filterMap, time);
}


void UVadRAnalyticsBlueprint::RegisterEventWithInfoAndFilter(FString eventName, FVector position, const TArray<FDataInfo>& info, const TArray<FDataFilter>& filter, float time){
	TMap<FString, float> infoMap;
	TMap<FString, FString> filterMap;
	int32 arrayLength = info.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && info[i].key == info[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Info should have unique keys. Key: " + info[i].key + " duplicated for event: " + eventName);
			return;
		}
		else {
			infoMap.Add(info[i].key, info[i].value);
		}
	}
	arrayLength = filter.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && filter[i].key == filter[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Filters should have unique keys. Key: " + filter[i].key + " duplicated for event: " + eventName);
			return;
		}
		else {
			filterMap.Add(filter[i].key, filter[i].value);
		}
	}
	IVadRAnalytics::Get().RegisterEvent(eventName, position, infoMap, filterMap, time);
}


FString UVadRAnalyticsBlueprint::StartEvent(FString eventName) {
	return IVadRAnalytics::Get().StartEvent(eventName);
}

FString UVadRAnalyticsBlueprint::StartEventWithInfo(FString eventName, const TArray<FDataInfo>& info) {
	TMap<FString, float> infoMap;
	int32 arrayLength = info.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && info[i].key == info[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Info should have unique keys. Key: " + info[i].key + " duplicated for event: " + eventName);
			return "";
		}
		else {
			infoMap.Add(info[i].key, info[i].value);
		}
	}
	return IVadRAnalytics::Get().StartEvent(eventName, infoMap);
}

FString UVadRAnalyticsBlueprint::StartEventWithFilters(FString eventName, const TArray<FDataFilter>& filter) {
	TMap<FString, FString> filterMap;
	int32 arrayLength = filter.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && filter[i].key == filter[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Filters should have unique keys. Key: " + filter[i].key + " duplicated for event: " + eventName);
			return "";
		}
		else {
			filterMap.Add(filter[i].key, filter[i].value);
		}
	}
	return IVadRAnalytics::Get().StartEvent(eventName, filterMap);
}

FString UVadRAnalyticsBlueprint::StartEventWithInfoAndFilters(FString eventName, const TArray<FDataInfo>& info, const TArray<FDataFilter>& filter) {
	TMap<FString, float> infoMap;
	TMap<FString, FString> filterMap;
	int32 arrayLength = info.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && info[i].key == info[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Info should have unique keys. Key: " + info[i].key + " duplicated for event: " + eventName);
			return "";
		}
		else {
			infoMap.Add(info[i].key, info[i].value);
		}
	}
	arrayLength = filter.Num();
	for (int32 i = 0; i < arrayLength; i++) {
		bool flag = true;
		for (int32 j = 0; j < arrayLength; j++)
		{
			if (j != i && filter[i].key == filter[j].key) {
				flag = false;
			}
		}
		if (!flag) {
			VadRLog::Log("Warning", "Filters should have unique keys. Key: " + filter[i].key + " duplicated for event: " + eventName);
			return "";
		}
		else {
			filterMap.Add(filter[i].key, filter[i].value);
		}
	}
	return IVadRAnalytics::Get().StartEvent(eventName, infoMap, filterMap);
}

void UVadRAnalyticsBlueprint::EndEvent(FString eventId, FVector pos, float gameTime) {
	IVadRAnalytics::Get().EndEvent(eventId, pos, gameTime);
}

void UVadRAnalyticsBlueprint::PersistVadrData(){
	IVadRAnalytics::Get().PersistData();
}

void UVadRAnalyticsBlueprint::ExportLevel(AActor* actor) {
	IVadRAnalytics::Get().ExportLevel(actor);
	//DataCollector::ExportLevel(directory);
}