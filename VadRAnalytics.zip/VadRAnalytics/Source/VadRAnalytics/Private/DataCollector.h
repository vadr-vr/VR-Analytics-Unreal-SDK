// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "VadRAnalyticsPCH.h"
#include "Components/SceneComponent.h"
#include "DataCollector.generated.h"

 DECLARE_LOG_CATEGORY_EXTERN(VadRDataLogger, Log, All);

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class VADRANALYTICS_API UDataCollector : public USceneComponent
{
	GENERATED_BODY()

private:
	void CollectGazeData();
	void CollectPositionData();
	void CollectFpsData();
	void init();
	FString checkRange(FHitResult* hit, AActor* actor, FVector forward);
	TArray<FVector> getDiagnols(AActor* actor);
	float currentTime;
	float writeTime;
	float postTime;
	float trackObjectTime;
	float writeDataFrequency = 10.0f;
	float postDataFrequency = 20.0f;
	int32 frameCount = 0;
	float fpsCount;

public:	
	// Sets default values for this component's properties
	UDataCollector();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	
public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	UPROPERTY(EditAnywhere)
		FString appId;
	UPROPERTY(EditAnywhere)
		FString appToken;
	UPROPERTY(EditAnywhere)
		FString version;
	UPROPERTY(EditAnywhere)
		FString sceneId;
	UPROPERTY(EditAnywhere)
		float collectionInterval;
	UPROPERTY(EditAnywhere)
		bool position;
	UPROPERTY(EditAnywhere)
		bool gaze;
	UPROPERTY(EditAnywhere)
		bool fps;
	UPROPERTY(EditAnywhere)
		float hitRange;
	UPROPERTY(EditAnywhere)
		TMap<FString, AActor*> trackObjects;
	UPROPERTY(EditAnywhere)
		bool testMode;

	//void ExportLevel(FString directory);
};
