// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "VadRAnalyticsPCH.h"
#include "Private/Objects/SceneClass.h"
#include "Private/Objects/SessionData.h"
#include "Private/Objects/EventClass.h"
#include "Private/Objects/StartEndEvents.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "Private/Utils/utils.h"
#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include "GameFramework/Actor.h"
#if WITH_EDITOR
#include "SNotificationList.h"
#include "NotificationManager.h"
#endif
#include "IVadRAnalytics.h"


/**
 * 
 */
namespace vadranalytics{
	class VadRAnalytics : public IVadRAnalytics
	{
	private:
		
		
		FString sceneToken = "";
		FString sceneId = "";
		float sceneStartTime;
		double sceneStartUnixTime;
		void RegisterEventHelper(EventClass singleEvent);
		void RegisterSessionToken();
		SessionData session;
		FCriticalSection event_mutex;
		TMap<FString, StartEndEvents*> startEndEvents;
		//bool exportSelected = false;
		void exportScene(UWorld* World, bool exportSelected);
		void setUpNotification(UWorld* World, bool exportSelected);
		TSharedPtr <SNotificationItem> NotificationScene;
		//UWorld* World;
	protected:
		// static VadRAnalytics* instance;
		void PostRequestComplete(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);
		FString ANALYTICS_FILE = "vadranalytics";
		FString ANALYTICS_FILE_BACK = "vadranalyticsback";
		FString TOKEN_FILE = "vadrsessiontoken";
		FString ANALYTICS_URL = "http://vadr.io/apiv1/registerData/";
		int32 timeout = 5;
		FCriticalSection file_mutex;
		FString appToken = "";
		FString appId = "";
		FString deviceToken = "";
		FString appDeviceToken = "";
		FString versionNo = "";
	public:
		VadRAnalytics();
		// VadRAnalytics* GetInstance();
		void RegisterEvent(FString eventName, FVector position, float time);
		void RegisterEvent(FString eventName, FVector position, TMap<FString, float> info, float time);
		void RegisterEvent(FString eventName, FVector position, TMap<FString, FString> filter, float time);
		void RegisterEvent(FString eventName, FVector position, TMap<FString, float> info, TMap<FString, FString> filter, float time);
		void StartScene(FString inSceneId, float time);
		void WriteToFile();
		void PersistData();
		void PostToServer();
		void SendData();
		void Init(FString inAppId, FString inAppToken, FString inVersionNo, bool inTestMode);
		FString ReadFromFile(); //This is a temp function
		void StartupModule() override;
		void ShutdownModule() override;
		FString StartEvent(FString eventName);
		FString StartEvent(FString eventName, TMap<FString, float> info);
		FString StartEvent(FString eventName, TMap<FString, FString> filters);
		FString StartEvent(FString eventName, TMap<FString, float> info, TMap<FString, FString> filters);
		void EndEvent(FString eventId, FVector pos, float gameTime);
		void ExportLevel(AActor* actor);
		~VadRAnalytics();
	};
}