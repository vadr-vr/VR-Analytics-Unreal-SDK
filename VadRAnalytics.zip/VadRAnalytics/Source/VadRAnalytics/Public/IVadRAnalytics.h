// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include "GameFramework/Actor.h"

/**
 * The public interface to this module.  In most cases, this interface is only public to sibling modules 
 * within this plugin.
 */


class IVadRAnalytics : public IModuleInterface
{

public:

	/**
	 * Singleton-like access to this module's interface.  This is just for convenience!
	 * Beware of calling this during the shutdown phase, though.  Your module might have been unloaded already.
	 *
	 * @return Returns singleton instance, loading the module on demand if needed
	 */
	static inline IVadRAnalytics& Get()
	{
		return FModuleManager::LoadModuleChecked< IVadRAnalytics >( "VadRAnalytics" );
	}

	/**
	 * Checks to see if this module is loaded and ready.  It is only valid to call Get() if IsAvailable() returns true.
	 *
	 * @return True if the module is loaded and ready to use
	 */
	static inline bool IsAvailable()
	{
		return FModuleManager::Get().IsModuleLoaded( "VadRAnalytics" );
	}
	
	virtual void RegisterEvent(FString eventName, FVector position, float time) = 0;
	virtual void RegisterEvent(FString eventName, FVector position, TMap<FString, float> info, float time) = 0;
	virtual void RegisterEvent(FString eventName, FVector position, TMap<FString, FString> filter, float time) = 0;
	virtual void RegisterEvent(FString eventName, FVector position, TMap<FString, float> info, TMap<FString, FString> filter, float time) = 0;
	virtual void StartScene(FString sceneId, float time) = 0;
	virtual void WriteToFile() = 0;
	virtual void PersistData() = 0;
	virtual void PostToServer() = 0;
	virtual void SendData() = 0;
	virtual FString ReadFromFile() = 0; //This is a temp function
	virtual void Init(FString inAppId, FString inAppToken, FString inVersionNo, bool inTestMode) = 0;
	virtual FString StartEvent(FString eventName) = 0;
	virtual FString StartEvent(FString eventName, TMap<FString, float> info) = 0;
	virtual FString StartEvent(FString eventName, TMap<FString, float> info, TMap<FString, FString> filters) = 0;
	virtual FString StartEvent(FString eventName, TMap<FString, FString> filters) = 0;
	virtual void EndEvent(FString eventId, FVector pos, float gameTime) = 0;
	virtual void ExportLevel(AActor* actor) = 0;
};

