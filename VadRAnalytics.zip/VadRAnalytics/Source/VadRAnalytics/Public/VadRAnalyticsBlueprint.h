#pragma once

#include "Private/VadRAnalyticsPCH.h"
#include "IVadRAnalytics.h"
#include "InputCoreTypes.h"
#include "GameFramework/Actor.h"
#include "VadRAnalyticsBlueprint.generated.h"

USTRUCT(BlueprintType)
struct FDataInfo
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(BlueprintReadWrite, Category="VadrAnalytics : Info")
	FString key;
	UPROPERTY(BlueprintReadWrite, Category="VadrAnalytics : Info")
	float value;

	FDataInfo(){}
};


USTRUCT(BlueprintType)
struct FDataFilter
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(BlueprintReadWrite, Category="VadrAnalytics : Info")
	FString key;
	UPROPERTY(BlueprintReadWrite, Category="VadrAnalytics : Info")
	FString value;

	FDataFilter(){}
};


UCLASS()
class UVadRAnalyticsBlueprint :  public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	
	UFUNCTION(BlueprintCallable, Category="VadrAnalytics : RegisterEvents")
	static void RegisterEvent(FString eventName, FVector position, float time);

	UFUNCTION(BlueprintCallable, Category="VadrAnalytics : StartScene")
	static void StartVadrScene(FString inSceneId, float time);

	UFUNCTION(BlueprintCallable, Category="VadrAnalytics : PersistData")
	static void PersistVadrData();

	UFUNCTION(BlueprintCallable, Category="VadrAnalytics : RegisterEvents")
	static void RegisterEventWithInfo(FString eventName, FVector position, const TArray<FDataInfo>& info, float time);

	UFUNCTION(BlueprintCallable, Category="VadrAnalytics : RegisterEvents")
	static void RegisterEventWithFilter(FString eventName, FVector position, const TArray<FDataFilter>& filter, float time);

	UFUNCTION(BlueprintCallable, Category="VadrAnalytics : RegisterEvents")
	static void RegisterEventWithInfoAndFilter(FString eventName, FVector position, const TArray<FDataInfo>& info, const TArray<FDataFilter>& filter, float time);

	UFUNCTION(BlueprintCallable, Category = "VadrAnalytics : StartEvent")
		static FString StartEvent(FString eventName);
	UFUNCTION(BlueprintCallable, Category = "VadrAnalytics : StartEvent")
		static FString StartEventWithInfo(FString eventName, const TArray<FDataInfo>& info);
	UFUNCTION(BlueprintCallable, Category = "VadrAnalytics : StartEvent")
		static FString StartEventWithInfoAndFilters(FString eventName, const TArray<FDataInfo>& info, const TArray<FDataFilter>& filter);
	UFUNCTION(BlueprintCallable, Category = "VadrAnalytics : StartEvent")
		static FString StartEventWithFilters(FString eventName, const TArray<FDataFilter>& filter);
	UFUNCTION(BlueprintCallable, Category = "VadrAnalytics : EndEvent")
		static void EndEvent(FString eventId, FVector pos, float gameTime);

	UFUNCTION(BlueprintCallable, Category = "VadrAnalytics : ExportScene")
		static void ExportLevel(AActor* actor);
};